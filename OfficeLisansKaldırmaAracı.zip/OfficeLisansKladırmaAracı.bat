@echo off
chcp 65001 >nul
cls
echo =============================================
echo     OFFICE LİSANSI KALDIRMA ARACI - CENK KARAKOL
echo =============================================

:: Office klasörünü kontrol et
set "ofisYolu="
if exist "C:\Program Files\Microsoft Office\Office16\ospp.vbs" (
    set "ofisYolu=C:\Program Files\Microsoft Office\Office16"
) else if exist "C:\Program Files (x86)\Microsoft Office\Office16\ospp.vbs" (
    set "ofisYolu=C:\Program Files (x86)\Microsoft Office\Office16"
) else (
    echo HATA: Office dizini bulunamadı!
    echo Lütfen Office 2019’un kurulu olduğundan emin olun.
    pause
    exit /b
)

cd /d "%ofisYolu%"

echo.
echo 🔎 Yüklü Office lisansları kontrol ediliyor...
echo ----------------------------------------------
cscript //nologo ospp.vbs /dstatus | findstr /i /c:"Last 5" /c:"License Name" /c:"License Status"

echo ----------------------------------------------
echo Yukarıda görünen lisans(lar) mevcuttur.
echo "Son 5 Karakter" kısmındaki değeri aşağıya giriniz.
echo Örn: ABCDE
echo.

set /p anahtar=Silmek istediğiniz lisansın son 5 karakteri: 

echo.
echo 🧹 Lisans kaldırılıyor (%anahtar%) ...
echo ----------------------------------------------
cscript //nologo ospp.vbs /unpkey:%anahtar% | findstr /i /c:"successfully" >nul

if %errorlevel%==0 (
    echo ✅ Lisans başarıyla kaldırıldı.
) else (
    echo ❌ Lisans kaldırma başarısız oldu!
    echo ➤ Lütfen doğru 5 karakteri girdiğinizden emin olun.
)

echo.
echo ✅ İşlem tamamlandı. Office yeniden başlatıldığında etkili olur.
echo ----------------------------------------------
pause
@echo off
chcp 65001 >nul
cls
echo =============================================
echo     OFFICE LİSANSI KALDIRMA ARACI - CENK KARAKOL
echo =============================================

:: Office klasörünü kontrol et
set "ofisYolu="
if exist "C:\Program Files\Microsoft Office\Office16\ospp.vbs" (
    set "ofisYolu=C:\Program Files\Microsoft Office\Office16"
) else if exist "C:\Program Files (x86)\Microsoft Office\Office16\ospp.vbs" (
    set "ofisYolu=C:\Program Files (x86)\Microsoft Office\Office16"
) else (
    echo HATA: Office dizini bulunamadı!
    echo Lütfen Office 2019’un kurulu olduğundan emin olun.
    pause
    exit /b
)

cd /d "%ofisYolu%"

echo.
echo 🔎 Yüklü Office lisansları kontrol ediliyor...
echo ----------------------------------------------
cscript //nologo ospp.vbs /dstatus | findstr /i /c:"Last 5" /c:"License Name" /c:"License Status"

echo ----------------------------------------------
echo Yukarıda görünen lisans(lar) mevcuttur.
echo "Son 5 Karakter" kısmındaki değeri aşağıya giriniz.
echo Örn: ABCDE
echo.

set /p anahtar=Silmek istediğiniz lisansın son 5 karakteri: 

echo.
echo 🧹 Lisans kaldırılıyor (%anahtar%) ...
echo ----------------------------------------------
cscript //nologo ospp.vbs /unpkey:%anahtar% | findstr /i /c:"successfully" >nul

if %errorlevel%==0 (
    echo ✅ Lisans başarıyla kaldırıldı.
) else (
    echo ❌ Lisans kaldırma başarısız oldu!
    echo ➤ Lütfen doğru 5 karakteri girdiğinizden emin olun.
)

echo.
echo ✅ İşlem tamamlandı. Office yeniden başlatıldığında etkili olur.
echo ----------------------------------------------
pause
